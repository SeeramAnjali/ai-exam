#include "GarageMonitor.h"
#include <cassert>
#include <sstream>
#include <iostream>
#include <cmath>
#include <vector>

static bool approx(double a, double b, double eps = 1e-9) {
    return std::fabs(a - b) < eps;
}

int main() {
    // 1) Severe Engine Stress scenario
    {
        GarageMonitor gm;
        gm.addDiagnostic("CarX", DiagnosticType::RPM, 6500);
        gm.addDiagnostic("CarX", DiagnosticType::EngineLoad, 95);
        gm.addDiagnostic("CarX", DiagnosticType::CoolantTemp, 120);
        auto st = gm.statusOf("CarX");
        assert(st.hasAll);
        assert(st.score.has_value());
        assert(*st.score < 40.0);
        assert(st.alert == "Severe Engine Stress");
    }

    // 2) Missing coolant temp -> Sensor Failure
    {
        GarageMonitor gm;
        gm.addDiagnostic("CarY", DiagnosticType::RPM, 3000);
        gm.addDiagnostic("CarY", DiagnosticType::EngineLoad, 50);
        auto st = gm.statusOf("CarY");
        assert(!st.hasAll);
        assert(st.alert == "Sensor Failure Detected");
        assert(!st.score.has_value());
    }

    // 3) Average score 70 and 30 -> 50
    {
        GarageMonitor gm;
        auto tempForScore = [](double s){ return 90.0 + (100.0 - s)/2.0; };
        double tA = tempForScore(70);
        gm.addDiagnostic("CarA", DiagnosticType::RPM, 0);
        gm.addDiagnostic("CarA", DiagnosticType::EngineLoad, 0);
        gm.addDiagnostic("CarA", DiagnosticType::CoolantTemp, tA);

        double tB = tempForScore(30);
        gm.addDiagnostic("CarB", DiagnosticType::RPM, 0);
        gm.addDiagnostic("CarB", DiagnosticType::EngineLoad, 0);
        gm.addDiagnostic("CarB", DiagnosticType::CoolantTemp, tB);

        auto avg = gm.averageScore();
        assert(avg.has_value());
        assert(approx(*avg, 50.0));
    }

    // 4) Boundary score = 40 -> no alert
    {
        GarageMonitor gm;
        gm.addDiagnostic("CarBnd", DiagnosticType::RPM, 0);
        gm.addDiagnostic("CarBnd", DiagnosticType::EngineLoad, 0);
        gm.addDiagnostic("CarBnd", DiagnosticType::CoolantTemp, 120);
        auto st = gm.statusOf("CarBnd");
        assert(st.hasAll);
        assert(st.score.has_value());
        assert(approx(*st.score, 40.0));
        assert(st.alert.empty());
    }

    // 5) Empty CSV must throw
    {
        GarageMonitor gm;
        std::stringstream emptyCSV("");
        std::vector<std::string> errors;
        bool threw = false;
        try {
            gm.loadCSV(emptyCSV, errors);
        } catch (...) {
            threw = true;
        }
        assert(threw);
    }

    // 6) Edge cases: invalid type, malformed value, negative values accepted
    {
        GarageMonitor gm;
        std::stringstream csv(
            "Car1, RPM, 1000\n"
            "Car1, BadType, 10\n"   // invalid type -> error list, ignored
            "Car1, EngineLoad, abc\n" // invalid value -> error list, ignored
            "Car1, CoolantTemp, -20\n" // negative allowed (formula math), still valid row
        );
        std::vector<std::string> errors;
        size_t n = 0;
        try {
            n = gm.loadCSV(csv, errors);
        } catch (...) {
            assert(false && "Should not throw with at least one valid row");
        }
        assert(n == 2); // RPM and CoolantTemp are valid rows
        assert(!errors.empty());
        auto st = gm.statusOf("Car1");
        assert(!st.hasAll); // missing EngineLoad
        assert(st.alert == "Sensor Failure Detected");
    }

    std::cout << "All tests passed.\n";
    return 0;
}
