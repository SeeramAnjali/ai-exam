# Garage Monitor (C++)

## Introduction
This project loads per-car diagnostic signals from CSV and reports engine health. It computes a **performance score** and triggers alerts based on thresholds. It also demonstrates **concurrency** using `std::thread` and `std::mutex` to simulate real-time updates and compares single-thread vs multi-thread performance.

### Score Formula
```
score = 100 - (rpm/100 + engineLoad*0.5 + (coolantTemp - 90) * 2)
```

### Alerts
- If any of RPM/EngineLoad/CoolantTemp is **missing**: `Sensor Failure Detected`
- If `score < 40`: `Severe Engine Stress`
- Exactly `score = 40`: **no alert**

## Files
- `Diagnostic.h/.cpp` – Diagnostic class & type helpers
- `Car.h/.cpp` – Holds diagnostics and computes score
- `GarageMonitor.h/.cpp` – Manages cars, CSV loading, status/alerts, aggregation, concurrency
- `main.cpp` – CLI entry-point
- `tests.cpp` – Unit & integration tests with `cassert` (no external deps)
- `CMakeLists.txt` – Build config
- `diagnostics.csv` – Example input

## Build & Run

### Using CMake
```bash
mkdir -p build && cd build
cmake ..
cmake --build .
```

Run the app:
```bash
./garage ../diagnostics.csv
```

Run unit/integration tests:
```bash
./tests
```

### Using g++ directly
```bash
g++ -std=c++17 -O2 -c Diagnostic.cpp Car.cpp GarageMonitor.cpp
g++ -std=c++17 -O2 -o garage main.cpp Diagnostic.o Car.o GarageMonitor.o
g++ -std=c++17 -O2 -o tests  tests.cpp Diagnostic.o Car.o GarageMonitor.o
```

## CSV Format
Each line: `CarId, Type, Value` (comma-separated, case-insensitive type).

Example:
```
Car1, RPM, 6500
Car1, CoolantTemp, 120
Car1, EngineLoad, 95
Car2, EngineLoad, 95
Car2, RPM, 4500
Car2, CoolantTemp, 88
```

**Empty CSV** (no valid data lines) will **throw** an exception.

## Sample Output
```
Loaded 6 row(s).
Car: Car1 | Score: -10.00 | Alert: Severe Engine Stress
Car: Car2 | Score: 54.00
```

## Concurrency Demo
You can simulate real-time updates and compare single-thread vs multi-thread performance:

```
./garage diagnostics.csv --simulate 2000 20
```

- Runs a 2000 ms simulation at 20 updates/sec/car.
- Prints elapsed time for single-thread and multi-thread runs.
- Internally uses `std::thread` (1 per car) and protects shared state with `std::mutex`.

## Explanation of Classes/Functions

### `Diagnostic`
- Holds `(carId, type, value)`
- Helper functions: `diagnosticTypeFromString`, `diagnosticTypeToString`

### `Car`
- Stores the latest values for RPM, EngineLoad, CoolantTemp
- `hasAllRequired()` to validate completeness
- `computePerformanceScore()` implements the formula above

### `GarageMonitor`
- `addDiagnostic(carId, type, value)`: Thread-safe insert/update
- `loadCSV(stream, errors)`: Parses CSV (collects non-fatal row errors). **Throws on empty CSV**
- `statusOf(carId)`: Returns `{hasAll, score, alert}`
- `printStatus(ostream)`: Pretty-prints all cars
- `averageScore()`: Averages across cars with complete data
- `simulateRealTimeUpdates(durationMs, updatesPerSecondPerCar, multithread)`: Real-time update loop(s)
