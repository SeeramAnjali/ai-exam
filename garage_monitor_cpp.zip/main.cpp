#include "GarageMonitor.h"
#include <fstream>
#include <iostream>
#include <vector>
#include <iomanip>

static void printUsage(const char* prog) {
    std::cerr << "Usage:\n"
              << "  " << prog << " <diagnostics.csv>\n"
              << "  " << prog << " <diagnostics.csv> --simulate [ms] [ups]\n"
              << "    ms  = simulation duration in milliseconds (default 2000)\n"
              << "    ups = updates per second per car (default 20)\n";
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        printUsage(argv[0]);
        return 1;
    }

    const char* path = argv[1];
    std::ifstream in(path);
    if (!in) {
        std::cerr << "Error: cannot open file: " << path << "\n";
        return 1;
    }

    GarageMonitor gm;
    std::vector<std::string> errors;
    try {
        size_t loaded = gm.loadCSV(in, errors);
        for (const auto& e : errors) std::cerr << "CSV Warning: " << e << "\n";
        std::cerr << "Loaded " << loaded << " row(s).\n";
    } catch (const std::exception& ex) {
        std::cerr << "CSV Error: " << ex.what() << "\n";
        return 1;
    }

    gm.printStatus(std::cout);

    if (argc >= 3 && std::string(argv[2]) == "--simulate") {
        int ms = (argc >= 4) ? std::stoi(argv[3]) : 2000;
        int ups = (argc >= 5) ? std::stoi(argv[4]) : 20;

        std::cout << "\n--- Real-time Simulation (" << ms << " ms, " << ups
                  << " updates/sec/car) ---\n";

        auto t1 = gm.simulateRealTimeUpdates(ms, ups, false);
        auto avg1 = gm.averageScore();
        std::cout << "Single-thread elapsed: " << t1 << " ms";
        if (avg1) std::cout << " | avg score: " << std::fixed << std::setprecision(2) << *avg1;
        std::cout << "\n";

        auto t2 = gm.simulateRealTimeUpdates(ms, ups, true);
        auto avg2 = gm.averageScore();
        std::cout << "Multi-thread elapsed:  " << t2 << " ms";
        if (avg2) std::cout << " | avg score: " << std::fixed << std::setprecision(2) << *avg2;
        std::cout << "\n";
    }

    return 0;
}
